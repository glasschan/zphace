# ZHpace - 中英文排版自動優化工具

ZHpace 是一個輕量級、高效的 WordPress 插件，能自動為中英文間添加空格，優化網站整體排版視覺體驗。

**貢獻者：** SEAFOODHOLDHAND 史佛浩恒  
**原始靈感：** [pangu.js](https://github.com/vinta/pangu.js) by vinta  
**標籤：** 中文，文本，格式化，排版，間距，標點，自動排版  
**要求 WordPress 版本：** 6.7 或更高  
**要求 PHP 版本：** 8.1 或更高  
**穩定標籤：** 1.1.2  
**許可證：** GPLv3 或更高版本  
**許可證 URI:** https://www.gnu.org/licenses/gpl-3.0.html  

## 描述

ZHpace 使用高效能 JavaScript 自動偵測頁面中的中英文文本，為它們之間添加適當的空格，遵循現代排版規範，顯著提升閱讀體驗。無需手動編輯，即可讓您的網站內容呈現出專業、一致的排版效果。

### 主要特點

- **自動排版優化**：智能識別並處理中英文、數字、符號之間的間距
- **即時處理**：支援動態生成內容的即時處理，適用於 AJAX 加載的內容
- **全站覆蓋**：自動處理整個網站的所有文本內容，包括文章、標題、評論等
- **輕量高效**：經過效能優化的代碼，對網站載入速度幾乎無影響
- **無需配置**：安裝即可使用，無需進行複雜設置

### 技術特點

- 使用高效正則表達式處理文本
- 智能節流控制，避免性能問題
- 支援透過過濾器自定義行為
- 可根據需要禁用特定頁面的處理

## 安裝

### 自動安裝

1. 在 WordPress 管理面板中，導航至「插件」>「添加新插件」
2. 搜索「ZHpace」
3. 點擊「安裝」按鈕，然後點擊「啟用」

### 手動安裝

1. 下載 ZHpace 插件 ZIP 檔案
2. 在 WordPress 管理面板中，導航至「插件」>「添加新插件」
3. 點擊「上傳插件」按鈕
4. 選擇下載的 ZIP 檔案並點擊「立即安裝」
5. 安裝完成後點擊「啟用插件」

或

1. 下載並解壓 ZHpace 插件
2. 使用 FTP 將 `zhpace` 資料夾上傳到 `/wp-content/plugins/` 目錄
3. 在 WordPress 管理面板中啟用插件

## 常見問題解答

### 此插件是否支援動態加載的內容？

是的，ZHpace 使用 MutationObserver 技術監視 DOM 變化，能夠自動處理通過 AJAX 或其他方式動態加載的內容。

### 插件會影響網站性能嗎？

ZHpace 經過精心優化，使用高效的代碼和智能節流技術，對網站性能的影響極小。

### 如何在特定頁面禁用 ZHpace？

開發者可以使用 `zhpace_disable` 過濾器在特定頁面禁用 ZHpace：

```php
add_filter('zhpace_disable', function() {
    // 在特定頁面返回 true 以禁用 ZHpace
    if (is_page('some-page')) {
        return true;
    }
    return false;
});
```

### 是否可以調整處理的頻率？

是的，可以使用 `zhpace_throttle` 過濾器調整節流值：

```php
add_filter('zhpace_throttle', function() {
    return 100; // 設置為 100 毫秒
});
```

## 致謝

特別感謝 [vinta](https://github.com/vinta) 開發的 [pangu.js](https://github.com/vinta/pangu.js) 項目，ZHpace 的核心理念受到該項目的啟發。

## 更新日誌

### 1.1.2
* 優化 JavaScript 性能和內存使用
* 添加更多過濾器以增強可擴展性
* 修復 DOM 變化處理中的潛在問題

### 1.1.0
* 添加對動態加載內容的支持
* 提升文本處理效率
* 改進錯誤處理

### 1.0.0
* 首次發布